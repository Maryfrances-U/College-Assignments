Maryfrances Umeora

mumeora@u.rochester.edu
BBID: mumeora
CSC 172: Lab 02
Grader: Linan Li


A Brief Explanation of the Lab
Task 1 was to print a 2D array, which I did easily with two for loops.
Task 2 was for running sums, which took a bit longer but I was ultimately able to figure out by taking note of whether the column or row was increasing or decreasing.
And Task 3 was just iterating, which was quite simple.