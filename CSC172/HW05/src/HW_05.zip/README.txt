Maryfrances Umeora
mumeora@u.rochester.edu
TA: Linan Li


IMPORTANT NOTE: I renamed the commands file I downloaded from BlackBoard to commands.txt
Just in case you're using it.


Brief Description of Lab
I did what he told us to do in the lab handout.
To run my code from command line, get to the directory where it is stored and type "java Lab5 commands.txt"  or whatever the commands file you'll be using is called.
Like I did in the last lab, I parsed the commands from the command document by passing the entire line into an array and checking what each string was. Then I use that information to call the methods insert, search, print, etc. For some, I used recursion, which is self explanatory when you see it.
All other necessary information can be found in the code's commments.