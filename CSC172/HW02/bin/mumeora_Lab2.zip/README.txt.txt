Maryfrances Umeora

mumeora@u.rochester.edu
BBID: mumeora
CSC 172: Lab 02
Grader: Linan Li


A Brief Explanation of the Lab
This lab's purpose was to show the advantages of using generics. 
The code starts by requiring input (separated by spaces) for an Integer array, a Double array, a Character array and a String array.
Then, using a variety of different types of methods, the code prints out the contents of the arrays in {a, b, c} format.
The code also returns the "max" values of each of the arrays.


Steps I Took to Build and Run My Code
First I separated all the stuff the teacher gave us with whitespace. It was very difficult to decipher beforehand.
Then I wrote the first method that takes in an array of objects and prints out all the elements of the arrays with a simple for loop.
For the second section, I did the exact same thing but with type-specific parameters. For the third section, it was still the same thing but with <T>.
Finally, for the last two sections, I looked to the TA for help using the Comparable type. Once I understood how to use it, I was able to easily compute the last two.
