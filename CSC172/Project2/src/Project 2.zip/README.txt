Maryfrances Umeora
mumeora@u.rochester.edu
Lab TAs: Linan Li


There are no specific instructions for running this. My code is well commented and very easy to understand.
The encode and decode methods are a bit long because I did not use a lot of external methods.The only other methods I used were:
-eighter: adds 0s in front of string to make sure they are all eight bits
-binaryMaker: creates the huffman-unique binary string for each character



