import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameDemo {
	
	public static void main(String [] args) {
		
		
	}

}
