import java.applet.*;
import java.net.MalformedURLException;
import java.net.URL;

public class Sound {
	
	public static final AudioClip BALL = Applet.newAudioClip(Sound.class.getResource("ball.wav"));
	public static final AudioClip BELL = Applet.newAudioClip(Sound.class.getResource("bells.wav"));
	public static final AudioClip GAMEOVER = Applet.newAudioClip(Sound.class.getResource("gameover.wav.wav"));
	public static final AudioClip YAYYY = Applet.newAudioClip(Sound.class.getResource("yay.wav"));
	

}
