	/* Maryfrances Umeora
		mumeora
		HW 07
		Lab Times: TR 11:05-12:20
		I did not collaborate with anyone on this assignment.
		   
		This abstract class creates a child Shape2D of parent Shape.
	*/

	public abstract class Shape2D extends Shape {
	
		public abstract double getArea();

}
