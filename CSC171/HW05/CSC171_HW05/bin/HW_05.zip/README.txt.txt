Maryfrances Umeora 
mumeora
HW 05
Lab Times: TR 11:05-12:20
I did not collaborate with anyone on this assignment.

I name my scanners "sc" instead of "scanner."
I have specified what each section of my code does with a comment above each section.
I did not use only one Main method. I have a different Main for each new class for each new question number.
To run each class and code, just press run. User input is not required by the teacher so I did not make any commands for the user.


Question #1
For this question, I have created the classes Q1Person and Q1Main.
Q1Person declares the instance variables "name," "age," and "phoNum." It has a constructor that takes in the variables "n" and "a" for name and age, as everyone always has a name and an age. There is a method phoNum() for the person's phone number if he/she has one. There are getters and setters for all variables. Finally, I have a toString() method.
Q1Main puts Q1Person to work. I created three Q1Person instances. Sophia is 15 and has 123-4567 as a phone number. Lala is 12 and too young to have a phone number. Margaret is 30 with a phone number of 585-876-5432. Then, as one of the requirements stated by the teacher is to change one of the instances I have created, I used the setAge() method to change Margaret's age. Once you hit "run," all of this should become obvious.

Question #2
For this question, I have created the classes Q2Elements and Q2Main.
Q2Elements declares the instance variables "name," "symbol," "atomNum,"(for atomic number) and "atomWei" (for atomic weight). atomWei is a double because the homework specified that this value could be fractional. This class has a constructor that takes in values for all the variables I have instantiated, as per the teacher's instruction. Finally, there are setters for all the variables, and a toString() method.
Q2Main tests Q2Elements. It creates three instances as per the teacher's instruction (Mr Pawlicki specified "several," which means "more than two but less than five"). I changed one of the instances, Instance 2, with a setName() method. I included a string statement to make this change seem more natural.

Question #3
For this question, I have created Q3Horse and Q3HorseMain.
Q3Horse is a class to represent the animal I have chosen: a horse. It declares the instance variables "breed," "color," and "food." A constructor takes in "b," "c," and "f" for each of these instance variables. There are also setters and getters for each variable. Because the teacher specified that he wanted at least one method other than the getters and setters, I created a fly() method. And of course, this class ends with a toString() method. 
Q3HorseMain runs on Q3Horse. It creates three instances of three different breeds of horses, two of which are fictional. One of these instances, the third one, runs the fly() method. I use the setBreed() method to change one of the instances, the third one, from a "Dapple-Gray" to a "Appaloosa," both of which are real, black-and-white spotted horses.

Question #4
For this question, I have created Q4Baseball and Q4Main.
Q4Baseball declares the instance variables name, game, bats, hits and runs, and a constructor takes these values in. Each of these values also has a setter and a getter. The teacher specified that there should be methods that compute batting average and runs per game, so I did just that, naming them batAvg() and runsGam() respectively. The class ends with a toString() method.
Q4Main, of course, applies Q4Baseball. It sends in the required paramenters to create a Q4Baseball instance. I created two instances in Q4Main. These instances print out the name of the baseball player, how many games the player has played, how many bats he's attempted, and hits and runs he's made. After that, I call the batting average and runs per game methods to print out the player's batting average and runs per game score. I added a few "\n" commands to improve the readability of my output. With this done, I have completed all the requirements for Question #4.



