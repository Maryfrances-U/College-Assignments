Maryfrances Umeora 
mumeora
HW 01
Lab Times: TR 11:05-12:20
I did not collaborate with anyone on this assignment.

Note: There is a comment above each section that specifies what each section of the code does.
Each new comment, with the exception of the block of code at the top that includes my name, denotes the beginning of a new number on the homework.
Also, I name my scanners "sc" instead of "scanner."