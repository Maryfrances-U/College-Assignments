import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* Maryfrances Umeora
		   mumeora
		   HW 02
		   Lab Times: TR 11:05-12:20
		   I did not collaborate with anyone on this assignment.
		 */
		
		Scanner sc = new Scanner(System.in);
		
		double a;
		System.out.println("Type in a number. Type \"0\" to stop");
		
		do	{
			a = sc.nextDouble();
			if (a != 0)
			System.out.println("The square is " + (a*a) + ". Enter another number.");	
		}
		while
			(a != 0);

	}

}
