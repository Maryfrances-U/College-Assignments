Maryfrances Umeora 
mumeora
HW 04
Lab Times: TR 11:05-12:20
I did not collaborate with anyone on this assignment.

Note: I name my scanners "sc" instead of "scanner."