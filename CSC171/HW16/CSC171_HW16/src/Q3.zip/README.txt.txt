Maryfrances Umeora
   mumeora
   HW 16
   Lab Times: TR 11:05-12:20
   I did not collaborate with anyone on this assignment


Question 1
Write a recursive function that finds the product of two numbers.
I will explain with an example.
Take x = 5 and y = 10.
5 < 10, so I call the function again this time with x = 10 and y = 5 because I want x to be the bigger number.
Since 10 != 0, return 10 + product(10, 5-1= 4)
Calling my function again, I'd get another 10 + product of (10, 4-1= 3)
Basically it'd keep going until y = 0. 
By the end of the program, we'd have added 10 5 times.
My main method prints the result.



Question 2
Write a recursive method that checks if a number is a palindrome.
At first, I created a boolean method that found the reverse of a user's entry and checked if they were equal.
But then I realized that it didn't call itself so I broke the program down.
Now, my method only finds the reverse of the input. I check whether or not they are equal in main.
Please ignore all the commented code. I just didn't want to delete it.



Question 3
Write a program that computes the nth Lucas number.
This was pretty easy to do. I just used te formula he gave us.


Question 4
Also simple using formula.
