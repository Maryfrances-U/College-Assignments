/* Maryfrances Umeora
   mumeora
   HW 09
   Lab Times: TR 11:05-12:20
   I did not collaborate with anyone on this assignment
*/
public class Q5Main {

	public static void main(String[] args) {
		
		TriangleTable tt = new TriangleTable(1);
		tt.printTriangle();
		
		System.out.println("");
		
		TriangleTable tt2 = new TriangleTable(2);
		tt2.printTriangle();

		System.out.println("");
		
		TriangleTable tt3 = new TriangleTable(3);
		tt3.printTriangle();

		System.out.println("");
		
		TriangleTable tt4 = new TriangleTable(4);
		tt4.printTriangle();

		System.out.println("");
		
		TriangleTable tt5 = new TriangleTable(5);
		tt5.printTriangle();

		System.out.println("");
		
		TriangleTable tt6 = new TriangleTable(6);
		tt6.printTriangle();

		System.out.println("");
		
		TriangleTable tt7 = new TriangleTable(7);
		tt7.printTriangle();

		System.out.println("");
		
		TriangleTable tt8 = new TriangleTable(8);
		tt8.printTriangle();

		System.out.println("");
		
		TriangleTable tt9 = new TriangleTable(9);
		tt9.printTriangle();

		System.out.println("");
		
		TriangleTable tt10 = new TriangleTable(10);
		tt10.printTriangle();

		System.out.println("");
		
	}

}
