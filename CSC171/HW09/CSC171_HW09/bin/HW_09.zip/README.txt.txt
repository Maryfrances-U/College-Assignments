/* Maryfrances Umeora
   mumeora
   HW 09
   Lab Times: TR 11:05-12:20
   I did not collaborate with anyone on this assignment
*/


I name my Scanners sc


Question 1
This was just a bunch of "trace this code" questions. 
I provided my answers in a separate text file.


Question 2
See above.


Question 3
For this class, I created the package "my.players," as per the teacher's instruction.
This package contains the classes mp3Player, saxPlayer and soccerPlayer.
SoccerPlayer is relatively simple, with the attributes name, team, position, height and weight. There are setters and getters for each variable. There is also a basic construtor and a toString statement.
SaxPlayer is also simple. A sax player has a name, a name for their instrument, a band, and a number of years playing. All other class conventions are included.
I was a little bit extra with mp3Player. It has an owner, color and storage, as well as an array of songs. There is a method to fill this array with songs. Then there is a method to print the songs, followed by a regular toString method.


Question 4
This question prompted to use packages to implement two classes both named Account.
One class represents bank accounts, while the other represents computer user accounts. Thus, though the class names remain the same, the packages are named accordingly.
The class Account representing a bank account has the properites owner, account number and balance. I used a DecimalFormat to always print the balance as a currency i.e 25.00 as opposed to 25.0
The class Account representing a user account has the properties profile image, username and password.
Both of these instances are illustrated in the class Q4Main in the default package.


Question 5
This code involved creating a TriangleTable class, then running it so that it prints out a bunch of triangles given a certain size.
I used concatenation to print out each line of the triangle, adding a new number "i" each time.
Then, in Q5Main, I created and printed 10 different triangles, as per the teacher's instruction.
